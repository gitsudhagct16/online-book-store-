package com.example.onlinebookstore.controller;

import com.example.onlinebookstore.model.Book;
import com.example.onlinebookstore.model.CartItem;
import com.example.onlinebookstore.repository.BookRepository;
import com.example.onlinebookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = "*") // allow all origins

public class BookController {

    @Autowired
    private BookService bookService;
    @Autowired
    private BookRepository repository;


    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = repository.findAll();
        return ResponseEntity.ok(books);
    }


}
