package com.example.onlinebookstore.controller;



import com.example.onlinebookstore.service.CartService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CheckoutController.class)
class CheckoutControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CartService cartService;

    @Test
    void checkout_shouldReturnSuccessMessage() throws Exception {
        doNothing().when(cartService).checkout();

        mockMvc.perform(post("/api/checkout"))
                .andExpect(status().isOk())
                .andExpect(content().string("Order placed successfully"));
    }
}

